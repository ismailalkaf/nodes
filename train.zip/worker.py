import binascii, json, hashlib, struct, threading, time, random, os, multiprocessing, sys
lib_dir = os.path.abspath("./libs")
sys.path.append(lib_dir)
import websocket

# Which algorithm for proof-of-work to use
ALGORITHM_MINOTAURX   = 'minotaurx'

ALGORITHMS = [ ALGORITHM_MINOTAURX ]

def load_config(file_path):
    config = {}
    with open(file_path, 'r') as file:
        for line in file:
            key, value = line.strip().split('=', 1)
            if key == 'port':
                value = int(value)
            elif key == 'threads':
              if value.startswith('['):
                value = json.loads(value)
              else:
                value = int(value)
            config[key] = value
    return config
    
# def log(message, level):
  # '''Conditionally write a message to stdout based on command line options and level.'''

  # global DEBUG
  # global DEBUG_PROTOCOL
  # global QUIET

  # if QUIET and level != LEVEL_ERROR: return
  # if not DEBUG_PROTOCOL and level == LEVEL_PROTOCOL: return
  # if not DEBUG and level == LEVEL_DEBUG: return

  # if level != LEVEL_PROTOCOL: message = '[%s] %s' % (level.upper(), message)

  # print ("[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), message))

# Convert from/to binary and hexidecimal strings (could be replaced with .encode('hex') and .decode('hex'))
hexlify = binascii.hexlify
unhexlify = binascii.unhexlify

def setInterval(func,time):
    e = threading.Event()
    while not e.wait(time):
        func()

def sha256d(message):
  '''Double SHA256 Hashing function.'''

  return hashlib.sha256(hashlib.sha256(message).digest()).digest()

def extract_hex_from_byte(item):
    if isinstance(item, bytes):
        hex_str = item.hex() 
        hex_str = hex_str.zfill(8)
        return hex_str
    else:
        return item

def swap_endian_word(hex_word):
  '''Swaps the endianness of a hexidecimal string of a word and converts to a binary string.'''

  message = unhexlify(hex_word)
  if len(message) != 4: raise ValueError('Must be 4-byte word')
  return message[::-1]


def swap_endian_words(hex_words):
    '''Swaps the endianness of a hexadecimal string of words and converts to a binary string.'''
    
    message = unhexlify(hex_words)
    if len(message) % 4 != 0: 
        raise ValueError('Must be 4-byte word aligned')
    
    swapped = b''.join([message[4 * i: 4 * i + 4][::-1] for i in range(len(message) // 4)])
    return swapped

def human_readable_hashrate(hashrate):
  '''Returns a human readable representation of hashrate.'''

  if hashrate < 1000:
    return '%2f B/s' % hashrate
  if hashrate < 10000000:
    return '%2f KB/s' % (hashrate / 1000)
  if hashrate < 10000000000:
    return '%2f MB/s' % (hashrate / 1000000)
  return '%2f GB/s' % (hashrate / 1000000000)

class Job(object):
  '''Encapsulates a Job from the network and necessary helper methods to mine.

     "If you have a procedure with 10 parameters, you probably missed some."
           ~Alan Perlis
  '''

  def __init__(
    self,
    job_id,
    prevhash,
    coinb1,
    coinb2,
    merkle_branches,
    version,
    nbits,
    ntime,
    target,
    extranonce1,
    extranonce2_size,
    proof_of_work,
    max_nonce=0xffffffff,
  ):

    # Job parts from the mining.notify command
    self._job_id = job_id
    self._prevhash = prevhash
    self._coinb1 = coinb1
    self._coinb2 = coinb2
    self._merkle_branches = [ b for b in merkle_branches ]
    self._version = version
    self._nbits = nbits
    self._ntime = ntime

    self._max_nonce = max_nonce

    # Job information needed to mine from mining.subsribe
    self._target = target
    self._extranonce1 = extranonce1
    self._extranonce2_size = extranonce2_size

    # Proof of work algorithm
    self._proof_of_work = proof_of_work

    # Flag to stop this job's mine coroutine
    self._done = False

    # Hash metrics (start time, delta time, total hashes)
    self._dt = 0.0
    self._hash_count = 0

  # Accessors
  id = property(lambda s: s._job_id)
  prevhash = property(lambda s: s._prevhash)
  coinb1 = property(lambda s: s._coinb1)
  coinb2 = property(lambda s: s._coinb2)
  merkle_branches = property(lambda s: [ b for b in s._merkle_branches ])
  version = property(lambda s: s._version)
  nbits = property(lambda s: s._nbits)
  ntime = property(lambda s: s._ntime)

  target = property(lambda s: s._target)
  extranonce1 = property(lambda s: s._extranonce1)
  extranonce2_size = property(lambda s: s._extranonce2_size)

  proof_of_work = property(lambda s: s._proof_of_work)


  @property
  def hashrate(self):
    '''The current hashrate, or if stopped hashrate for the job's lifetime.'''
    if self._dt == 0: return 0.0
    return self._hash_count / self._dt


  def merkle_root_bin(self, extranonce2_bin):
    '''Builds a merkle root from the merkle tree'''

    coinbase_bin = unhexlify(self._coinb1) + unhexlify(self._extranonce1) + extranonce2_bin + unhexlify(self._coinb2)
    coinbase_hash_bin = sha256d(coinbase_bin)

    merkle_root = coinbase_hash_bin
    for branch in self._merkle_branches:
      merkle_root = sha256d(merkle_root + unhexlify(branch))
    return merkle_root


  def stop(self):
    '''Requests the mine coroutine stop after its current iteration.'''
    self._done = True

  def mine(self, nonce_start=0, nonce_stride=1):
    t0 = time.time()
    
    # Generate a random extranonce2
    extranonce2 = '{:0{}x}'.format(random.randint(0, 2**(8 * self.extranonce2_size) - 1), self.extranonce2_size * 2)
    extranonce2_bin = struct.pack('<I', int(extranonce2, 16))
    merkle_root_bin = self.merkle_root_bin(extranonce2_bin)
    header_prefix_bin = swap_endian_word(self._version) + swap_endian_words(self._prevhash) + merkle_root_bin + swap_endian_word(self._ntime) + swap_endian_word(self._nbits)

    for nonce in range(nonce_start, self._max_nonce, nonce_stride):
      # This job has been asked to stop
      if self._done:
        self._dt += (time.time() - t0)
        raise StopIteration()

      # Proof-of-work attempt
      nonce_bin = struct.pack('<I', nonce)
      pow = hexlify(self.proof_of_work(header_prefix_bin + nonce_bin)[::-1]).decode('utf-8')

      # Did we reach or exceed our target?
      if pow <= self.target:
        result = dict(
          job_id = self.id,
          extranonce2 = hexlify(extranonce2_bin),
          ntime = str(self._ntime),                    # Convert to str from json unicode
          nonce = hexlify(nonce_bin[::-1])
        )
        self._dt += (time.time() - t0)

        yield result

        t0 = time.time()

      self._hash_count += 1

  def __str__(self):
    return '<Job id=%s prevhash=%s coinb1=%s coinb2=%s merkle_branches=%s version=%s nbits=%s ntime=%s target=%s extranonce1=%s extranonce2_size=%d>' % (self.id, self.prevhash, self.coinb1, self.coinb2, self.merkle_branches, self.version, self.nbits, self.ntime, self.target, self.extranonce1, self.extranonce2_size)

class Subscription(object):
  '''Encapsulates the Subscription state from the JSON-RPC server'''

  _max_nonce = None

  # Subclasses should override this
  def ProofOfWork(header):
    raise Exception('Do not use the Subscription class directly, subclass it')

  class StateException(Exception): pass

  def __init__(self):
    self._id = None
    self._difficulty = None
    self._extranonce1 = None
    self._extranonce2_size = None
    self._target = None
    self._worker_name = None
    self._mining_thread = None

  # Accessors
  id = property(lambda s: s._id)
  worker_name = property(lambda s: s._worker_name)

  difficulty = property(lambda s: s._difficulty)
  target = property(lambda s: s._target)

  extranonce1 = property(lambda s: s._extranonce1)
  extranonce2_size = property(lambda s: s._extranonce2_size)

  def set_worker_name(self, worker_name):
    if self._worker_name:
      raise self.StateException('Already authenticated as %r (requesting %r)' % (self._username))

    self._worker_name = worker_name

  def _set_target(self, target):
    self._target = '%064x' % target

  def set_difficulty(self, difficulty):
    if difficulty < 0: raise self.StateException('Difficulty must be non-negative')

    # Compute target
    if difficulty == 0:
      target = 2 ** 256 - 1
    else:
      target = min(int((0xffff0000 * 2 ** (256 - 64) + 1) / difficulty - 1 + 0.5), 2 ** 256 - 1)

    self._difficulty = difficulty
    self._set_target(target)

  def set_subscription(self, subscription_id, extranonce1, extranonce2_size):
    if self._id is not None:
      raise self.StateException('Already subscribed')

    self._id = subscription_id
    self._extranonce1 = extranonce1
    self._extranonce2_size = extranonce2_size

  def create_job(self, job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime):
    '''Creates a new Job object populated with all the goodness it needs to mine.'''

    if self._id is None:
      raise self.StateException('Not subscribed')

    return Job(
      job_id=job_id,
      prevhash=prevhash,
      coinb1=coinb1,
      coinb2=coinb2,
      merkle_branches=merkle_branches,
      version=version,
      nbits=nbits,
      ntime=ntime,
      target=self.target,
      extranonce1=self._extranonce1,
      extranonce2_size=self.extranonce2_size,
      proof_of_work=self.ProofOfWork,
      max_nonce=self._max_nonce,
    )

  def __str__(self):
    return '<Subscription id=%s, extranonce1=%s, extranonce2_size=%d, difficulty=%d worker_name=%s>' % (self.id, self.extranonce1, self.extranonce2_size, self.difficulty, self.worker_name)

class SubscriptionMinotaurx(Subscription):
  '''Subscription for Minotaurx-based coins.'''

  import minotaurx_hash
  ProofOfWork = minotaurx_hash.getPoWHash
  _max_nonce = 0xffffffff

  def _set_target(self, target):
    self._target = '%064x' % target

# Maps algorithms to their respective subscription objects
SubscriptionByAlgorithm = {
  ALGORITHM_MINOTAURX: SubscriptionMinotaurx,
}

class Worker():
  '''Simple mining client'''

  def __init__(self, proxy, pool_host, pool_port, username, password, threads=4, algorithm=ALGORITHM_MINOTAURX):
    self._proxy = proxy
    self._pool_host = pool_host
    self._pool_port = pool_port
    self._username = username
    self._password = password
    self._threads_range = threads if isinstance(threads, (list, tuple)) else None
    self._threads = threads[0] if isinstance(threads, (list, tuple)) else threads

    self._subscription = SubscriptionByAlgorithm[algorithm]()

    self._job = []
    self._ws = None

    self._accepted_shares = 0
    self._accepted_hash = 0
    self._queue = multiprocessing.Queue()
    self._stop_event = multiprocessing.Event()
    self._processes = []
    self._hashrates = []

  # Accessors
  proxy = property(lambda s: s._proxy)
  pool_host = property(lambda s: s._pool_host)
  pool_port = property(lambda s: s._pool_port)
  username = property(lambda s: s._username)
  password = property(lambda s: s._password)
  threads = property(lambda s: s._threads)

  def _set_threads(self):
    if self._threads_range is not None:
      self._threads = random.randint(self._threads_range[0], self._threads_range[1])

  def _console_log(self, hashrate):
    os.system('clear')
    print("\033[92mServer Port       : %d\033[0m" % 8080)
    print("\033[92mNumber Users      : %d\033[0m" % self._accepted_shares)
    print("\033[92mConnection Speed  : %s\033[0m" % human_readable_hashrate(hashrate))


  # Cleanuo jobs process
  def _cleanup(self):
    self._queue.empty()

    for job in self._job:
      job.stop()

    for process in self._processes:
      process.terminate()
      process.join()

    self._processes = []
    self._job = []

  # Excute job
  def _spawn_job_thread(self, job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime):
    '''Stops any previous job and begins a new job.'''

    # Create the new job
    return self._subscription.create_job(
      job_id = job_id,
      prevhash = prevhash,
      coinb1 = coinb1,
      coinb2 = coinb2,
      merkle_branches = merkle_branches,
      version = version,
      nbits = nbits,
      ntime = ntime
    )
  
  def run(self, job, nonce):
      try:
        for result in job.mine(nonce_start=nonce):
          submit_data = {
              'id': 'mining.submit',
              'method': 'mining.submit',
              'params': [
                self._subscription.worker_name,
                result['job_id'],
                result['extranonce2'].decode('ascii'),
                result['ntime'],
                result['nonce'].decode('ascii'),
              ]
          }
          self._queue.put(json.dumps(submit_data))
          self._console_log(job.hashrate * self.threads)
      except Exception as e:
        print(e)
        pass

  def queue_message(self):
    while True:
      if not self._queue.empty():
        shared = self._queue.get()
        self._ws.send(shared)
      else:
        time.sleep(0.5)

  def on_open(self, ws):
    # connect
    connect_data = {
        'id': 'proxy.connect',
        'method': 'proxy.connect',
        'params': [self.pool_host, self.pool_port]
    }
    ws.send(json.dumps(connect_data))

    # subcribe
    subscribe_data = {
        'id': 'mining.subscribe',
        'method': 'mining.subscribe',
        'params': ["MOMOSHIKI"]
    }
    ws.send(json.dumps(subscribe_data))

    # start queue message
    thread = threading.Thread(target = self.queue_message)
    thread.daemon = True
    thread.start()

  def on_message(self, ws, message):
    json_strings = message.split('\n')

    for json_data_str in json_strings:
        if not json_data_str.strip():
          continue
        
        data = json.loads(json_data_str)
        method = data.get('method') or data.get('id')
        params = data.get('params') or data.get('result')
        error = data.get('error') or None

        if method == "mining.submit":
            if error is not None:
              # log(f"Invalide shares: {error}", LEVEL_ERROR)
              pass
            else:
              self._accepted_shares += 1
              # log('Accepted shares: %d' % self._accepted_shares, LEVEL_INFO)
              # self._console_log()

        elif method == 'mining.authorize':
            self._subscription.set_worker_name(self.username)

        elif method == "mining.set_difficulty":
            (difficulty, ) = params
            self._subscription.set_difficulty(difficulty)
            # log('Change difficulty: difficulty=%s' % difficulty, LEVEL_DEBUG)

        elif method == "mining.subscribe":
            ((mining_notify, subscription_id), extranonce1, extranonce2_size) = params
            self._subscription.set_subscription(subscription_id, extranonce1, extranonce2_size)
            # log('Subscribed: subscription_id=%s' % subscription_id, LEVEL_DEBUG)

            extranonce_data = {
                'id': 'mining.extranonce.subscribe',
                'method': 'mining.extranonce.subscribe',
                'params': []
            }
            ws.send(json.dumps(extranonce_data))

            auth_data = {
                'id': 'mining.authorize',
                'method': 'mining.authorize',
                'params': [self.username, self.password]
            }
            ws.send(json.dumps(auth_data))
            
        elif method == "mining.notify":
            if len(params) != 9:
                raise self.MinerWarning('Malformed mining.notify message', json_strings)

            (job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime, clean_jobs) = params

            # log('New job: %s' % job_id, LEVEL_DEBUG)
            
            # Cleanup any previous jobs
            self._cleanup()

            # Random threads
            self._set_threads()

            # Start mining
            for index in range(self.threads):
              # Spawn the jobs
              work = self._spawn_job_thread(job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime)
              self._job.append(work)

              # Multithreads
              nonce = index * self._subscription._max_nonce // self.threads

              thread = multiprocessing.Process(target=self.run, args=(work,nonce))
              thread.daemon = True
              thread.start()

              self._processes.append(thread)

        elif method == "mining.extranonce":
            (extranonce, ) = params
            self._subscription.set_extranonce(extranonce)
            # log('New extranonce: %s' % extranonce, LEVEL_DEBUG)

        elif method == "mining.extranonce.subscribe":
            # log('Extranonce Subscribe: %s' % params, LEVEL_DEBUG)
            pass

  def on_error(self, ws, msg):
    pass

  def on_close(self, ws, b, c):
    pass

  def serve_forever(self):
    '''Begins the miner. This method does not return.'''
    websocket.enableTrace(False)
    self._ws = websocket.WebSocketApp(self.proxy, on_open=self.on_open, on_message=self.on_message, on_error=self.on_error, on_close=self.on_close)
    self._console_log(0)
    self._ws.run_forever()